// apps/mdx/model.js
import { getTenantDb } from "../../server/core/db/mongo.js";

const COLLECTION = "mdx_docs";

export async function listDocs(tenantId) {
  const db = await getTenantDb(tenantId);
  return db
    .collection(COLLECTION)
    .find({})
    .project({ mdx: 0 })
    .sort({ updatedAt: -1 })
    .toArray();
}

export async function getDoc(tenantId, slug) {
  const db = await getTenantDb(tenantId);
  return db.collection(COLLECTION).findOne({ slug });
}

export async function upsertDoc(tenantId, { slug, title, mdx }) {
  const db = await getTenantDb(tenantId);
  const now = new Date();

  await db.collection(COLLECTION).updateOne(
    { slug },
    {
      $set: { title, mdx, updatedAt: now },
      $setOnInsert: { createdAt: now }
    },
    { upsert: true }
  );

  return getDoc(tenantId, slug);
}
